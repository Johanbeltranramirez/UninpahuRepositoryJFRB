import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonButton } from '@ionic/angular/standalone';

@Component({
  selector: 'app-lista-productos',
  templateUrl: './lista-productos.component.html',
  styleUrls: ['./lista-productos.component.scss'],
  standalone: true,
  imports: [IonButton, CommonModule]
})

export class ListaProductosComponent  implements OnInit {

  activo: boolean = false;
  listaFrutas: string[] = ["Pera", "Manzana", "Fresa", "Piña"];
  listaObjetos = [
    
    {
      nombre: "Melisa",
      edad: 14
    },
    {
      nombre: "Maicol",
      edad: 42
    },
    {
      nombre: "Anita",
      edad: 72
    }
    
  ];

  listaProductos = [

    {
      nomProd: "Lápiz",
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTg6GhnhYv8G-NAD7PEuRwSe_PuBIRIO95n1A&s",
      material: "",
      marca: "",
      precio: "",
      moneda:"",
      vendido: false,
      proveedor: "",
      almacen: "",
    },
    {
      nomProd: "",
      img: "",
      material: "",
      marca: "",
      precio: "",
      moneda:"",
      vendido: false,
      proveedor: "",
      almacen: "",
    },
    {
      nomProd: "",
      img: "",
      material: "",
      marca: "",
      precio: "",
      moneda:"",
      vendido: false,
      proveedor: "",
      almacen: "",
    },
    {
      nomProd: "",
      img: "",
      material: "",
      marca: "",
      precio: "",
      moneda:"",
      vendido: false,
      proveedor: "",
      almacen: "",
    },
    {
      nomProd: "",
      img: "",
      material: "",
      marca: "",
      precio: "",
      moneda:"",
      vendido: false,
      proveedor: "",
      almacen: "",
    },
    {
      nomProd: "",
      img: "",
      material: "",
      marca: "",
      precio: "",
      moneda:"",
      vendido: false,
      proveedor: "",
      almacen: "",
    },
    {
      nomProd: "",
      img: "",
      material: "",
      marca: "",
      precio: "",
      moneda:"",
      vendido: false,
      proveedor: "",
      almacen: "",
    },
    {
      nomProd: "",
      img: "",
      material: "",
      marca: "",
      precio: "",
      moneda:"",
      vendido: false,
      proveedor: "",
      almacen: "",
    },
    {
      nomProd: "",
      img: "",
      material: "",
      marca: "",
      precio: "",
      moneda:"",
      vendido: false,
      proveedor: "",
      almacen: "",
    },
    {
      nomProd: "",
      img: "",
      material: "",
      marca: "",
      precio: "",
      moneda:"",
      vendido: false,
      proveedor: "",
      almacen: "",
    }
    
  ]


  constructor() { }

  ngOnInit() {}

  cambiarValor(){
    this.activo = !this.activo;
  }
}
