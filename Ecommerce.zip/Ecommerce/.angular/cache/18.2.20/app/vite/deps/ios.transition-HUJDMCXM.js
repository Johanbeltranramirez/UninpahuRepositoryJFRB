import {
  iosTransitionAnimation,
  shadow
} from "./chunk-PFBU7Q5F.js";
import "./chunk-SXS62EXI.js";
import "./chunk-44IZU6OF.js";
import "./chunk-X47IVTLT.js";
import "./chunk-R4SJUBFW.js";
import "./chunk-CBIR4FRL.js";
import "./chunk-QHQP2P2Z.js";
export {
  iosTransitionAnimation,
  shadow
};
//# sourceMappingURL=ios.transition-HUJDMCXM.js.map
